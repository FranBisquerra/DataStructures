# Estructura de dades - Pràctica II
## 1. És el meu abre ACB?
Llegeix d'un fitxer el recorregut d'un arbre en *inordre* i *preordre* a raó de in per línia i amb aquest ordre.
Construeix l'arbre.
Comprova que el recorregut *inordre* de l'arbre construït sigui igual que el del fitxer.
Comprova si l'arbre es un arbre de cerca binària (ACB).
Imprimeix els resultats per pantalla i alhora escriu a un fitxer un '0' si no compleix la condició, sinó un '1'.

## 2. Has path sum
Llegeix d'un fitxer el recorregut d'un arbre en *inordre* i *preordre* a raó de in per línia i amb aquest ordre.
Construeix l'arbre.
Comprova si el nombre introduït per paràmetres es igual a la suma d'algún dels path fins arribar a un dels nodes fulla.
Imprimeix els resultats per pantalla i alhora escriu a un fitxer un '0' si no compleix la condició, sinó un '1'.

### Particularitats generals d'ambdos exercicis:
Ha d'existir el fitxer _resultats.txt_ a la carpeta principal.